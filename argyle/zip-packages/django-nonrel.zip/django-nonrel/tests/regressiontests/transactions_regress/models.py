from django.db import models

class Mod(models.Model):
    fld = models.IntegerField()
