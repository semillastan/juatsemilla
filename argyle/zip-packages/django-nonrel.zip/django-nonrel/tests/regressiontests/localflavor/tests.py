from django.test import TestCase
from django.utils import unittest

# just import your tests here
from us.tests import *
